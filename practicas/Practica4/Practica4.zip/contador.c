#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>


char* ledBinario(int num){
	FILE *fichero = fopen("../../../dev/leds", "w");
	switch(num){
		case 0: fputs( "0", fichero); break;
		case 1: fputs( "3", fichero); break;
		case 2: fputs( "2", fichero); break;
		case 3: fputs( "23", fichero); break;
		case 4: fputs( "1", fichero); break;
		case 5: fputs( "13", fichero); break;
		case 6: fputs( "12", fichero); break;
		case 7: fputs( "123", fichero); break;
		default: fputs( "0", fichero); break;
		
	}
	fclose(fichero);
}

int main(int argc, char *argv[]) {		
		int cuenta = 0;
		int contador = 0;
		ledBinario(contador);
		sleep(2);
		while(contador <= 7){			
			contador = contador + 1;
			ledBinario(contador);
			sleep(2);
		}	
}


